open index.html
click on locations list at top of screen to center map on that location
click map marker to see information about that location
